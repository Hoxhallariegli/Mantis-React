import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';

function App() {
    return (
        <Router>
            <Layout>
                <h1>Mirësevini në aplikacionin tim!</h1>
                <p>Këtu është përmbajtja kryesore.</p>
            </Layout>
        </Router>
    );
}

export default App;
