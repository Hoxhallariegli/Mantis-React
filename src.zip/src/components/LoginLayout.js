import React from 'react';

export default function LoginLayout({ children }) {
    return (
        <div style={{ minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center', background: '#f5f5f5' }}>
            {children}
        </div>
    );
}

