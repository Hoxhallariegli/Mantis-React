import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { loginUser } from '../redux/slices/authSlice';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
export default function LoginForm() {
    const dispatch = useDispatch();
    const auth = useSelector(state => state.auth) || { loading: false, error: null };
    console.log('Redux auth state:', auth);

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();


    useEffect(() => {
        if (auth && auth.user) {
            navigate('/');
        }
    }, [auth, navigate]);


    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await dispatch(loginUser({ email, password })).unwrap();

            toast.success("Login successful!");
            navigate('/');  // redirect në faqen kryesore (ndrysho sipas dëshirës)
        } catch (err) {
            console.error('Failed to login:', err);
            toast.error("Login failed: Invalid credentials");
        }
    };


    return (
        <>
        {auth?.error && <p>{auth.error}</p>}

    <form onSubmit={handleSubmit} style={{ maxWidth: 400, margin: 'auto', marginTop: 50 }}>
            <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                style={{ width: '100%', padding: 10, marginBottom: 10, fontSize: 16 }}
            />
            <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                style={{ width: '100%', padding: 10, marginBottom: 10, fontSize: 16 }}
            />
            <button
                type="submit"
                disabled={auth.loading}
                style={{
                    width: '100%',
                    padding: 10,
                    fontSize: 16,
                    cursor: auth.loading ? 'not-allowed' : 'pointer',
                }}
            >
                {auth.loading ? 'Loading...' : 'Login'}
            </button>
            {auth.error && <p style={{ color: 'red', marginTop: 10 }}>{auth.error}</p>}
        </form>
        </>
    );
}
