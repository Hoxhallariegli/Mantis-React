import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useSelector } from 'react-redux';

export default function ProtectedRoute() {
    const auth = useSelector(state => state.auth);
    console.log('ProtectedRoute auth:', auth);

    if (!auth || !auth.user) {
        return <Navigate to="/login" replace />;
    }

    return <Outlet />;
}
