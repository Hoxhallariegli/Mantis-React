// import React from 'react';
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import Layout from './components/Layout';
// import Dashboard from './pages/Dashboard';
// import Profile from './pages/Profile';
// import Settings from './pages/Settings';
// import LoginForm from './components/LoginForm';
// import LoginLayout from './components/LoginLayout';
// import ProtectedRoute from './components/ProtectedRoute';
// import { ToastContainer } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import { useDispatch, useEffect } from 'react-redux';
// import { setCredentials } from './slices/authSlice';
// function App() {
//     const dispatch = useDispatch();
//
//     useEffect(() => {
//         const token = localStorage.getItem('token');
//         const user = localStorage.getItem('user');
//         if (token && user) {
//             dispatch(setCredentials({ token, user: JSON.parse(user) }));
//         }
//     }, [dispatch]);
//     return (<>
//             <ToastContainer position="top-right" autoClose={3000} />
//         <Router>
//             <Routes>
//                 {/* Login page me LoginLayout */}
//                 <Route path="/login" element={
//                     <LoginLayout>
//                         <LoginForm />
//                     </LoginLayout>
//                 } />
//
//                 {/* Rruget që duhen mbrojtur */}
//                 <Route element={<ProtectedRoute />}>
//                     <Route path="/" element={<Layout />}>
//                         <Route index element={<Dashboard />} />
//                         <Route path="profile" element={<Profile />} />
//                         <Route path="settings" element={<Settings />} />
//                     </Route>
//                 </Route>
//             </Routes>
//         </Router>
//         </>
//     );
// }
//
// export default App;
import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Provider } from 'react-redux';
import { store } from './app/store';

import Login from './pages/Login';
import Dashboard from './pages/Dashboard';

function App() {
    return (
        <Provider store={store}>
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Navigate to="/login" replace />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/dashboard" element={<Dashboard />} />
                    <Route path="*" element={<Navigate to="/login" replace />} />
                </Routes>
            </BrowserRouter>
        </Provider>
    );
}

const container = document.getElementById('app');
const root = createRoot(container);
root.render(<App />);
