import React from 'react';

export default function Profile() {
    return <h1>Your Profile Page</h1>;
}
