import React from 'react';

export default function Settings() {
    return <h1>Settings Page</h1>;
}
