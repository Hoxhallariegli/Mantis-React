// import React from 'react';
//
// export default function Dashboard() {
//     return <h1>Welcome to the Dashboard!</h1>;
// }
import axios from 'axios';

import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchUser, logout as clearAuth } from '../features/auth/authSlice';

function Dashboard() {
    const dispatch = useDispatch();
    const { user } = useSelector(state => state.auth);

    useEffect(() => {
        if (!user) {
            dispatch(fetchUser());
        }
    }, [user, dispatch]);

    const handleLogout = async () => {
        try {
            await axios.post('/api/logout');         // 1) Thirr API logout
            dispatch(clearAuth());                   // 2) Pastro store‐in
            window.location.href = '/login';         // 3) Redirect
        } catch (err) {
            console.error('Logout error:', err);
        }
    };

    if (status === 'loading') return <p>Loading…</p>;
    if (!user) return <p>Not authenticated. Go To <a href='/login'>Login Page</a> </p>;

    return (
        <div>
            <h2>Dashboard</h2>
            <p>Welcome, {user.name}</p>
            <button onClick={handleLogout}>Logout</button>
        </div>
    );
}

export default Dashboard;
