import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { login, fetchUser } from '../features/auth/authSlice';

function Login() {
    const dispatch = useDispatch();
    const { status, error, user } = useSelector(state => state.auth);
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = e => {
        e.preventDefault();
        dispatch(login({ email, password }));
    };

    useEffect(() => {
        if (status === 'succeeded') {
            dispatch(fetchUser()).then(() => {
                window.location.href = '/dashboard';
            });
        }
    }, [status, dispatch]);

    return (
        <div>
            <h2>Login</h2>
            {error && <p style={{color:'red'}}>{error.message}</p>}
            <form onSubmit={handleSubmit}>
                <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" />
                <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" />
                <button disabled={status==='loading'} type="submit">
                    {status === 'loading' ? 'Logging in…' : 'Login'}
                </button>
            </form>
        </div>
    );
}

export default Login;
